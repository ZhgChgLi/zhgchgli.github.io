import os
import json
from PIL import Image, ImageFilter
font_path = "assets/fonts/font.ttf"

def generate_lqip_images(root_dir='../../assets', output_subdir='lqip', blur_radius=8, jpeg_quality=10):
    output_path_root = os.path.abspath(os.path.join(root_dir, output_subdir))
    img_path_root = os.path.abspath(os.path.join(root_dir, 'img'))
    lib_path_root = os.path.abspath(os.path.join(root_dir, 'lib'))

    # 圖片尺寸與文字
    width, height = 800, 400
    text = "Loading..."

    # 建立白色背景圖片
    img = Image.new("RGB", (width, height), color="white")
    draw = ImageDraw.Draw(img)

    # 使用預設字型或自訂字型
    try:
        # 如果你有 TTF 字型檔案，可以指定路徑
        font = ImageFont.truetype(font_path, 48)
    except:
        # 否則用預設字型
        font = ImageFont.load_default()

    # 計算文字尺寸以便置中
    text_width, text_height = draw.textsize(text, font=font)
    text_x = (width - text_width) // 2
    text_y = (height - text_height) // 2

    # 畫出文字
    draw.text((text_x, text_y), text, font=font, fill="black")

    # 儲存圖片
    img.save("loading_image.png")

    for dirpath, _, filenames in os.walk(root_dir):
        abs_dirpath = os.path.abspath(dirpath)
        if (
            abs_dirpath.startswith(output_path_root) or
            abs_dirpath.startswith(img_path_root) or
            abs_dirpath.startswith(lib_path_root)
        ):
            continue

        for filename in filenames:
            if not filename.lower().endswith(('.jpg', '.jpeg', '.png', '.gif', '.webp')):
                continue

            input_path = os.path.join(dirpath, filename)
            try:
                with Image.open(input_path) as img:
                    width, height = img.size
                    print(f"圖片寬度: {width}px")
                    print(f"圖片高度: {height}px")

            except Exception as e:
                print(f"❌ Failed: {input_path} - {e}")

if __name__ == '__main__':
    generate_lqip_images()